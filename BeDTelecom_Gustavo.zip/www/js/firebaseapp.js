var config = {
    apiKey: "AIzaSyDpW8tKv6hXnC1iLA8Zt7WAbmq7LpUQyIs",
    authDomain: "gustavolopesselin-bikcraft.firebaseapp.com",
    databaseURL: "https://gustavolopesselin-bikcraft.firebaseio.com",
    projectId: "gustavolopesselin-bikcraft",
    storageBucket: "gustavolopesselin-bikcraft.appspot.com",
    messagingSenderId: "186889214638"
  };
  firebase.initializeApp(config);
